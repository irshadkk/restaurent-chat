'use strict';

// Settings configured here will be merged into the final config object.
export default {
  api: 'http://localhost:4008'
}
